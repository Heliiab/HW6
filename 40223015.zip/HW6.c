// Helia Bayat    40223015
#include <stdio.h>
#include <math.h>
float solver(float a, float b, float c, float *, float *);
int main()
{
    float a, b, c, x1, x2, *p1 = &x1, *p2 = &x2;
    printf("Enter 3 real numbers:\n");
    scanf("%f%f%f", &a, &b, &c);
    if ((a == 0) && (b == 0))
        printf("You entered incorrect numbers.");
    else
    {
        solver(a, b, c, p1, p2);

        if ((b * b) - (4 * a * c) > 0)
        {
            printf("\nThis equation has 2 real roots.");
            printf("\nroots:");
            printf("\n%f\n%f", *p1, *p2);
        }
        else if (((a != 0) && (b != 0)) && (((b * b) - (4 * a * c)) == 0))
        {
            printf("\nThis equation has 1 real root.");
            printf("\nroot:");
            printf("\n%f", *p1);
        }
        else if (((b * b) - (4 * a * c)) < 0)
            printf("\nThis equation has no real roots.");
    }
    return 0;
}

float solver(float a, float b, float c, float *p1, float *p2)
{
    if ((b * b) - (4 * a * c) > 0)
    {
        *p1 = ((-b) + sqrt((b * b) - (4 * a * c))) / (2 * a);
        *p2 = ((-b) - sqrt((b * b) - (4 * a * c))) / (2 * a);
    }
    else if (((a != 0) && (b != 0)) && (((b * b) - (4 * a * c)) == 0))
    {
        *p1 = (-b) / (2 * a);
    }
}